package cinema;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Xxfir
 */
public class Scene3Controller implements Initializable {

    @FXML
    private AnchorPane anchr3;
    @FXML
    private MenuBar menubr3;
    @FXML
    private Menu filemenu;
    @FXML
    private MenuItem closeit;
    @FXML
    private Menu editmenu;
    @FXML
    private MenuItem cbc;
    @FXML
    private ColorPicker bckgrcolorpick;
    @FXML
    private SeparatorMenuItem sprt;
    @FXML
    private MenuItem ctc;
    @FXML
    private ColorPicker txtrcolorpick;
    @FXML
    private Label lblrpt;
    @FXML
    private Label lblGnr;
    @FXML
    private Button gnrButton;
    @FXML
    private Separator sprt2;
    @FXML
    private Label lbl1;
    @FXML
    private Label lbl2;
    @FXML
    private Label lbl3;
    @FXML
    private Label lbl4;
    @FXML
    private Button endButton;
    private Stage stage;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onClck_menuItem_Closeit(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    private void onClck_menuItem_Cbc(ActionEvent event) {
        Color myColor = bckgrcolorpick.getValue();
      anchr3.setBackground(new Background(new BackgroundFill(myColor, null, null)));
    }

    @FXML
    private void onClck_menuItem_Ctc(ActionEvent event) {
      Color myColor2 =  txtrcolorpick.getValue();
      lblrpt.setTextFill(myColor2);
      lblGnr.setTextFill(myColor2);
      lbl1.setTextFill(myColor2);
      lbl2.setTextFill(myColor2);
      lbl3.setTextFill(myColor2);
      lbl4.setTextFill(myColor2);
    }
    
    @FXML
    public void onClck_btn_genrate(ActionEvent ex){
    String line = "";
    try{
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt"));
        
         String[] lines = new String[4];
         int index = 0;
         while ((line = reader.readLine()) != null) {   
         lines[index++] = line;
         if (index==4) break;
        }
         lbl1.setText(lines[0]);
         lbl2.setText(lines[1]);
         lbl3.setText(lines[2]);
         lbl4.setText(lines[3]);
        
    }catch(Exception er){
     er.printStackTrace();
    }
    
    }
    
    @FXML
    public void onClck_btn_end_Program(ActionEvent ex){
    Alert alert = new Alert(AlertType.CONFIRMATION);
    alert.setTitle("End Program");
    alert.setHeaderText("You're about to end the program!");
    alert.setContentText("Do you want to save before exiting?: ");
    
    if(alert.showAndWait().get() == ButtonType.OK){
        stage = (Stage) anchr3.getScene().getWindow();
    }
    System.out.println("You successfully ended the program!");
    stage.close();
    
    }
    
}
