package cinema;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import java.io.*;
import javafx.geometry.Insets;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.fxml.FXMLLoader;
import javafx.scene. Parent;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Xxfir
 */
public class Scene1Controller implements Initializable {

    @FXML
    private AnchorPane anchr1;
    @FXML
    private MenuBar menubr;
    @FXML
    private Menu filemenu;
    @FXML
    private MenuItem closeit;
    @FXML
    private Menu editmenu;
    @FXML
    private MenuItem cbc;
    @FXML
    private SeparatorMenuItem sprt;
    @FXML
    private MenuItem ctc;
    @FXML
    private Label lbl1;
    @FXML
    private Label lbl2;
    @FXML
    private Label lbl3;
    @FXML
    private TextField tf1;
    @FXML
    private TextField tf2;
    @FXML
    private Button strtBtn;
    @FXML
    private ColorPicker bckgrcolorpick;
    @FXML
    private ColorPicker txtrcolorpick;
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void onClck_menuItem_Closeit(ActionEvent e){
    Platform.exit();    
    }
    
    @FXML
    public void onClck_menuItem_Cbc(ActionEvent e){
       Color myColor = bckgrcolorpick.getValue();
       anchr1.setBackground(new Background(new BackgroundFill(myColor, null, null)));
    }
    
    @FXML
    public void onClck_menuItem_Ctc(ActionEvent e){
      Color myColor2 =  txtrcolorpick.getValue();
      lbl1.setTextFill(myColor2);
      lbl2.setTextFill(myColor2);
      lbl3.setTextFill(myColor2);
    }
    
    @FXML
    public void onClck_btn_Start(ActionEvent e){
        
        String name = tf1.getText().toString();
        String id = tf2.getText().toString();
        try{
                
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",false);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("Name: " + name + "\n");
                out.write("ID: " + id + "\n");
                out.close();
              }catch(Exception ex){
                System.out.println("Error while writing to file: " + ex.getMessage());
              }
        
     try{
          
     FXMLLoader loader = new FXMLLoader(getClass().getResource("scene2.fxml"));
     root = loader.load();
     
     Scene2Controller scene2Controller = new Scene2Controller();
     scene2Controller = loader.getController();
     scene2Controller.diplayname(name , id);
             
     stage = (Stage) ((Node)e.getSource()).getScene().getWindow();
     scene = new Scene(root);
     stage.setScene(scene);
     stage.show();
     }catch(Exception ey){
      ey.printStackTrace();   
     }
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
