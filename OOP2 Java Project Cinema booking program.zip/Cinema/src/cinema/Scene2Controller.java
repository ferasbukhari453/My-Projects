package cinema;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import java.io.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Xxfir
 */
public class Scene2Controller implements Initializable {

    @FXML
    private AnchorPane anchr2;
    @FXML
    private MenuBar menubr;
    @FXML
    private Menu filemenu;
    @FXML
    private MenuItem closeit;
    @FXML
    private Menu editmenu;
    @FXML
    private MenuItem cbc;
    @FXML
    private ColorPicker bckgrcolorpick;
    @FXML
    private SeparatorMenuItem sprt;
    @FXML
    private MenuItem ctc;
    @FXML
    private ColorPicker txtrcolorpick;
    @FXML
    private Label welcomemsg;
    @FXML
    private Label lblchose;
    @FXML
    private Label lblmovie;
    @FXML
    private Label lbltime;
    @FXML
    private MenuButton moviemenu;
    @FXML
    private MenuButton timemenu;
    @FXML
    private RadioMenuItem movie1;
    @FXML
    private RadioMenuItem movie2;
    @FXML
    private RadioMenuItem movie3;
    @FXML
    private RadioMenuItem time1;
    @FXML
    private RadioMenuItem time2;
    @FXML
    private RadioMenuItem time3;
    @FXML
    private Button confirmch;
    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onClck_menuItem_Closeit(ActionEvent event) {
       Platform.exit(); 
    }

    @FXML
    private void onClck_menuItem_Cbc(ActionEvent event) {
      Color myColor = bckgrcolorpick.getValue();
      anchr2.setBackground(new Background(new BackgroundFill(myColor, null, null)));
    }

    @FXML
    private void onClck_menuItem_Ctc(ActionEvent event) {
      Color myColor2 =  txtrcolorpick.getValue();
      welcomemsg.setTextFill(myColor2);
      lblchose.setTextFill(myColor2);
      lblmovie.setTextFill(myColor2);
      lbltime.setTextFill(myColor2);
    }
    
    public void diplayname(String name, String id){
    welcomemsg.setText("Hello: " + name + " " + id);
    }
    
    
    @FXML
    public void onClck_btn_confirm_Choise(ActionEvent ex){
    if (movie1.isSelected()){
              String moviename1 = movie1.getText().toString(); 
              try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("You Choose" + " " + moviename1 + " " + "Movie" + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }else if(movie2.isSelected()){
            String moviename2 = movie2.getText().toString(); 
              try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("You Choose" + " " + moviename2 + " " + "Movie" + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }else if(movie3.isSelected()){
            String moviename3 = movie3.getText().toString(); 
              try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("You Choose" + " " + moviename3 + " " + "Movie" + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }
            
            if(time1.isSelected()){
                String timex1 = time1.getText().toString();
                try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("At time: " + " " + timex1 + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }else if(time2.isSelected()){
            String timex2 = time2.getText().toString();
                try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("At time: " + " " + timex2 + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }else if(time3.isSelected()){
            String timex3 = time3.getText().toString();
                try{
                FileWriter fstream = new FileWriter("C:\\Users\\Xxfir\\java source\\Cinema\\src\\cinema\\log.txt",true);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("At time: " + " "  + timex3 + "\n");
                out.close();
              }catch(Exception e){
                System.out.println("Error while writing to file: " + e.getMessage());
              }
            }
            
             try{
          
     FXMLLoader loader = new FXMLLoader(getClass().getResource("scene3.fxml"));
     root = loader.load();      
     stage = (Stage) ((Node)ex.getSource()).getScene().getWindow();
     scene = new Scene(root);
     stage.setScene(scene);
     stage.show();
     }catch(Exception ey){
      ey.printStackTrace();   
     }
            
    }
}
    
    