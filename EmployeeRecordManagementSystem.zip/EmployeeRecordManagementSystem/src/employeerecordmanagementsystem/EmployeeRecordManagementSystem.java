package employeerecordmanagementsystem;

/**
 *
 * @author Xxfir
 */
import java.util.Scanner;

class Employee {
	int id;
	String name;
	String startDate;
	String phone;
	String address;
	int hours;
	double salary;
      Employee next;
      

	public Employee(int id, String name, String startDate, String phone, String address, int hours, double salary) {
		this.id = id;
		this.name = name;
		this.startDate = startDate;
		this.phone = phone;
		this.address = address;
		this.hours = hours;
		this.salary = salary;
           
	}

	public void display() {
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("Start Date: " + startDate);
		System.out.println("Phone: " + phone);
		System.out.println("Address: " + address);
		System.out.println("Hours: " + hours);
		System.out.println("Salary: " + salary);
	}
}


class LinkedList {
	Employee head;
        
     public boolean checkRecord(int id) {
        Employee temp = head;
        while (temp != null) {
            if (temp.id == id) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

	public void insert(int id, String name, String startDate, String phone, String address, int hours, double salary) {
  
            if (!checkRecord(id)) {
            Employee newEmployee = new Employee(id, name, startDate, phone, address, hours, salary);
            if (head == null) {
                head = newEmployee;
            } else {
                Employee temp = head;
                while (temp.next != null) {
                    temp = temp.next;
                }
                temp.next = newEmployee;
            }
            System.out.println("Record created successfully.");
        } else {
            System.out.println("Record with ID " + id + " already exists.");
        }
	}
        
//      public void updateRecord(int id, Employee data) {
//        Employee temp = head;
//        while (temp != null) {
//            if (temp.data.id == id) {
//                temp.data = data;
//                System.out.println("Record updated successfully");
//                return;
//            }
//            temp = temp.next;
//        }
//        System.out.println("Record not found");
//    }

	public void delete(int id) {
		Employee current = head;
		Employee prev = null;

		while (current != null && current.id != id) {
			prev = current;
			current = current.next;
		}

		if (current == null) {
			System.out.println("Employee not found.");
			return;
		}

		if (prev == null) {
			head = current.next;
		} else {
			prev.next = current.next;
		}
	}

	public void updateSalary(int id, int newHours) {
		Employee current = head;

		while (current != null && current.id != id) {
			current = current.next;
		}

		if (current == null) {
			System.out.println("Employee not found.");
			return;
		}

		current.hours = newHours;
		current.salary += (newHours ) * (current.salary * 2 / 100);
	}

	public void display() {
		Employee current = head;

		while (current != null) {
			current.display();
			current = current.next;
		}
	}

	public Employee search(int id) {
		Employee current = head;

		while (current != null && current.id != id) {
			current = current.next;
		}

		return current;
	}
}


public class EmployeeRecordManagementSystem {

	public static void main(String[] args) {
            try (Scanner sc = new Scanner(System.in)) {
                LinkedList employees = new LinkedList();
                
                OUTER:
                while (true) {
                    System.out.println("Enter your choice: ");
                    System.out.println("1. Insert Employee Record");
                    System.out.println("2. Delete Employee Record");
                    System.out.println("3. Update Employee Salary");
                    System.out.println("4. Display Employees");
                    System.out.println("5. Search Employee");
                    System.out.println("6. Exit");
                    
                   int choice = sc.nextInt();
                    
                    switch (choice) {
                        case 1:
                        {
                            System.out.println("Enter employee ID: ");
                            int id = sc.nextInt();
                            System.out.println("Enter employee name: ");
                            sc.nextLine();
                            String name = sc.nextLine();
                            System.out.println("Enter start date: ");
                            String startDate = sc.nextLine();
                            System.out.println("Enter phone: ");
                            String phone = sc.nextLine();
                            System.out.println("Enter address: ");
                            String address = sc.nextLine();
                            System.out.println("Enter hours: ");
                            int hours = sc.nextInt();
                            System.out.println("Enter salary: ");
                            double salary = sc.nextDouble();
                            employees.insert(id, name, startDate, phone, address, hours, salary);
                            break;
                        }
                        case 2:
                        {
                            System.out.println("Enter employee ID: ");
                            int id = sc.nextInt();
                            employees.delete(id);
                            break;
                        }
                        case 3:
                        {
                            System.out.println("Enter employee ID: ");
                            int id = sc.nextInt();
                            System.out.println("Enter new hours: ");
                            int newHours = sc.nextInt();
                            employees.updateSalary(id, newHours);
                            break;
                        }
                        case 4:
                            employees.display();
                            break;
                        case 5:
                        {
                            System.out.println("Enter employee ID: ");
                            int id = sc.nextInt();
                            Employee emp = employees.search(id);
                            if (emp == null) {
                                System.out.println("Employee not found.");
                            } else {
                                System.out.println("Employee found: ");
                                emp.display();
                            }
                            break;
                        }
                        case 6:
                            break OUTER;
                        default:
                            break;
                    }
                }
            }
	}
}